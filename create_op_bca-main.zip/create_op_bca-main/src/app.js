const express = require("express");
const port = process.env.PORT || 3000;
const app = express();
const hbs = require("hbs");
const path = require("path");
const body_parser = require("body-parser");
const mongoose = require("mongoose");

// Database connection
require("./db/conn");

// Model
const register = require("./models/register");

// Paths
const views_path = path.join(__dirname, "../templates/views");
const index_path = path.join(__dirname, "../templates/index");
// Middleware
app.use(body_parser.json());
app.use(body_parser.urlencoded({ extended: false }));

// View engine setup
app.set("view engine", "hbs");
app.set("views", views_path);
app.use(express.static(index_path));

// Server start
app.listen(port, () => {
  console.log(`Running on Port: ${port}`);
});

// Routes
app.get("/index", (req, res) => {
  res.render("index"); // index.hbs should contain the form
});

app.get("/data", (req, res) => {
  res.send("I AM COMING FROM BACKEND !");
});

app.get("/geo", (req, res) => {
  res.send("THIS IS A MINOR CLASS");
});

app.get("/bca", (req, res) => {
  res.send("this is a full stack class");
});

// POST route to save data
app.post("/send", (req, res) => {
  const { name, roll, school, hostelInfo } = req.body;

  const save_data = new register({ name, roll, school, hostelInfo });
  console.log("Received form data:", req.body);

  save_data
    .save()
    .then(() => {
      console.log("Data Saved to DB!");
      res.send("Data sent to backend!");
    })
    .catch((e) => {
      console.log(`Error: ${e}`);
      res.status(500).send("Error saving data");
    });
});

// Display route
app.get("/display", async (req, res) => {
  try {
    const data = await register.find();
    console.log(data);
    res.render("display", { data }); // display.hbs should render the table
  } catch (e) {
    console.error(e);
    res.status(500).send("Error fetching data");
  }
});
