const mongoose = require("mongoose");

const userData = new mongoose.Schema({
    name: { type: String, required: true },
    roll: { type: String, required: true },
    school: { type: String, required: true },
    hostelInfo: { type: String, required: true }
});

const Register = mongoose.model("userData", userData);
module.exports = Register;
